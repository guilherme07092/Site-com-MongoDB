var http = require("http");
var exp = require("express");
var app = exp();
app.set("view engine", "ejs");
var mongoose = require("mongoose");
var bp = require("body-parser");
app.use(bp());
mongoose.connect("mongodb://localhost/web");
app.set('view engine', 'ejs');

var servidor = http.createServer(app);

var cadastroUsuario = mongoose.Schema({
    cnome: 'String',
    cusuario: 'String',
    csenha: 'String',
    cemail: 'String',
    csexo: 'String',
    ccpf: 'Number',
    cdata: 'Date'
});

var novoCadastro = mongoose.model('Cadastro', cadastroUsuario);

app.get('/home', function (req, resp) {
    resp.render('home');
});

app.get('/registro', function (req, resp) {
    resp.render('registro');
});

app.get('/sobre', function (req, resp) {
    resp.render('sobre');
});

app.post('/efetuacadastro', function (req, resp) {
    var nome = req.body.nomeRegistro;
    var usuario = req.body.usuarioRegistro;
    var senha = req.body.senhaRegistro;
    var email = req.body.emailRegistro;
    var sexo = req.body.sexoRegistro;
    var cpf = req.body.cpfRegistro;
    var data = req.body.dataRegistro;

    console.log("nome = ", nome);

    var novo = new novoCadastro({
        cnome: nome,
        cusuario: usuario,
        csenha: senha,
        cemail: email,
        csexo: sexo,
        ccpf: cpf,
        cdata: data
    });
    novo.save();
    resp.render('home');

});

app.post('/efetuaLogin', function (req, resp) {
    var pegarLogin = req.body.usuario;
    var pegarSenha = req.body.senha;
    novoCadastro.find({cusuario: pegarLogin, csenha: pegarSenha}, function (err, objs) {
        if (objs.length == 1) {
            resp.render('lab07');
        } else {
            resp.render('registro');
        }

    })

});


app.get("/usuarios",function(req,resp){
    novoCadastro.find(function(err,objs){
        resp.render('usuarios',{posts:objs})
    })
});
servidor.listen(8000);
